# Scatter Py

## Instructions

* Using the [starter file](Unsolved/ice_cream_sales_unsolved.ipynb), create a scatter plot that matches the image provided.

## Bonus

* Create a new list called `scoop_price`, fill it with values, and then set it so that the size of the dots are set according to those values.

- - -

© 2019 Trilogy Education Services
